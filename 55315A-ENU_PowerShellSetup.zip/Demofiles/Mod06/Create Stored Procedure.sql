-- Create a stored procedure used for inserts

-- 1. Create the procedure
USE Demo6
GO
SET IDENTITY_INSERT Person.Customer ON
GO

CREATE PROCEDURE USP_InsertCustomer 
@CustomerID int
,@name varchar (50)
,@DateofBirth datetime
,@Address varchar (50)
AS
INSERT INTO Person.Customer([CustomerID],[Name],[DateOfBirth],[Address]) 
VALUES
(@CustomerID
,@name
,@DateOfBirth
,@Address);
GO

-- 2. Execute the procedure
EXECUTE USP_InsertCustomer 
@CustomerID = 89,
@name = 'Antoine Domino',
@DateOfBirth = '1928-02-26',
@Address = '1 Blueberry Hill'
GO

-- 3. View the results
SELECT * FROM Person.Customer
GO


SET IDENTITY_INSERT Person.Customer OFF


