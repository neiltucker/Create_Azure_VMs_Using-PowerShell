Remove-Item $Labfiles\Sources -Recurse -Force -ErrorAction SilentlyContinue
DisMount-Diskimage -DevicePath \\.\CDROM0 -ErrorAction SilentlyContinue
DisMount-Diskimage -DevicePath \\.\CDROM1 -ErrorAction SilentlyContinue
New-Item -ItemType "Directory" -Path $Labfiles\Sources\Sxs -Force
$DCImage = Mount-DiskImage $DCISO 
$DCPath = $DCImage.DevicePath
$DCDrive = $DCPath.Substring(4,6)
Copy-Item -Path $DCPath"\"\Sources\sxs -Destination $Labfiles\Sources -Recurse -Force
DisMount-DiskImage -DevicePath $DCPath 

