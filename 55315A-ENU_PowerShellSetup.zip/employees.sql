CREATE TABLE [dbo].[Employees] (
[ID] INT CONSTRAINT [PK_InvoiceID] PRIMARY KEY,
[LastName] [nvarchar](50) NULL,
[FirstName] [nvarchar](50) NULL,
[HireDate] [nvarchar](50) NULL,
[HireTime] [int] NULL)
Go
