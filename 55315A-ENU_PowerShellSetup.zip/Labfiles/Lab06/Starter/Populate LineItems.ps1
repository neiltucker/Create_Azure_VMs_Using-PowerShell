Import-Module SQLServer
Set-Location SQLServer:\SQL\localhost
Invoke-SQLCMD -Inputfile C:\Classfiles\Labfiles\Lab06\Starter\Setup\populatelineitems.sql

