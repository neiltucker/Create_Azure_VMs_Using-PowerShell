import pyodbc
conn = pyodbc.connect('Driver={SQL Server};Server=vm55264srv;Database=Master;Trusted_Connection=yes;AutoCommit=True')
conn.autocommit = True
cursor = conn.cursor()
try: cursor.execute('Create Database Database1')
except: pass
try: cursor.execute('USE Database1')
except: pass
try: cursor.execute('Create Table database1.dbo.goldprices ([Date] Date, [Price] Decimal(18,10))')
except: pass
try: cursor.execute("Bulk Insert goldprices From 'c:\\labfiles\\goldprices.csv' With (FIELDTERMINATOR = ',', FIRSTROW = 2, ROWTERMINATOR = '\\n', MAXERRORS = 100, ERRORFILE = 'c:\\labfiles\\errorfile.txt')")
except: pass
conn.close()
