# Update the PowerShell Help Files on the server
Update-Help -SourcePath "C:\Classfiles\PSHelp" -Force
