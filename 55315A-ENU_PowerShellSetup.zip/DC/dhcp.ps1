Install-WindowsFeature -IncludeManagementTools DHCP
Netsh dhcp add securitygroups
Restart-Service DHCPServer
Add-DHCPServerInDC MIA-SQL 192.168.10.100
netsh dhcp server import c:\classfiles\dc\dhcpdb12 all
Restart-Service DHCPServer
Set-DHCPServerv4Scope -ScopeID 192.168.10.0 -State Active
Set-DHCPServerv4Scope -ScopeID 192.168.20.0 -State Active
Set-DHCPServerv4OptionValue -DNSServer 192.168.10.100
Set-DHCPServerv4OptionValue -ScopeID 192.168.10.0 -DNSServer 192.168.10.100
Set-DHCPServerv4OptionValue -ScopeID 192.168.20.0 -DNSServer 192.168.10.100