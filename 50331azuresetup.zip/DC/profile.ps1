set-executionpolicy unrestricted
import-module servermanager
